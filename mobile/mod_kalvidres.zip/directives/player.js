angular.module('mm.core')

.directive('kalturaPlayer', function($stateParams) {
    
    var module = $stateParams.module;
	return {

		restrict: 'E',
        scope: {
            
             pid:"@pid",
             uiconfid:"@uiconfid",
             entryid:"@entryid",
             playerid: "@playerid"
        },
        	
		link: function($scope, element, attributes) {

            element.append("this is in player directive before iframe creation"+attributes.pid+" " +attributes.entryid+" "+attributes.uiconfid);
			//if (document.getElementById("kalturaLib") === null){
                
                var d = document.createElement('div');
                d.className="mma-mod_kaltura_video_container";
				var s = document.createElement('iframe');
                s.id = "kalturaLib";
                s.width=attributes.width;
                s.height = attributes.height;
				//s.async = false;
				  
                s.src = 'https://urcourses-video.uregina.ca/p/'+attributes.pid+'/sp/'+attributes.pid+'00/embedIframeJs/uiconf_id/'+attributes.uiconfid+'/partner_id/'+attributes.pid+'?iframeembed=true&playerId=kaltura_player&entry_id='+attributes.entryid+'&flashvars[autoPlay]=true&flashvars[share.plugin]=true';
                    
                d.appendChild(s);
                element.append(d);
                element.append("this is in player directive after iframe creation");
               
			//}

			   var linkFunction = function($scope, element, attributes) {
				if (attributes.width){
					$scope.width = attributes.width;
				}
				if (attributes.height){
					$scope.height = attributes.height;
				}
				if (attributes.id){
					$scope.id = attributes.id;
				}


				if (!$scope.kdp){
					var intervalID = setInterval(function(){
						if (typeof window.kWidget !== "undefined"){
							clearInterval(intervalID);

							var target = attributes.id ? "kaltura_player_"+attributes.id : "kaltura_player_";
							var flashvars = attributes.flashvars ? JSON.parse(attributes.flashvars) : {};

							window.kWidget.embed({
								"targetId": target,
								"wid": "_"+attributes.pid,
								"uiconf_id": attributes.uiconfid,
								"flashvars": flashvars,
								"cache_st": Math.random(),
								"entry_id": attributes.entryid,//attributes.entryid,
								"readyCallback": function(playerID){
									$scope.kdp = document.getElementById(playerID);
									$rootScope.$broadcast('kalturaPlayerReady', $scope.kdp, attributes.id);
								}
							});
						}
					},50);
				}
			}
			return linkFunction;
		}
	}
});