/*
* This directive takes html content of page or book and searches for any kaltura video links
* The links are then rewritten as kaltura iframes inorder to show the video within the mobile app
*
* Proper format in call directive in html: <content-display content="{{content}}" uiconfid="{{uiconfid}}"></content-display>  
*
*/
angular.module('mm.core')
.directive('contentDisplay', function() {
  return {
        restrict: 'E',
        scope: {
             content:"@content",
             uiconfid:"@uiconfid",
             
        },
        replace:false,
        link: function($scope, element, attrs) {
            
         //The watch is used incase the first time directive is called there is no uiconfid passed
         //If the uiconfid changes then the entire directive reloads
          $scope.$watch('uiconfid',function(){     
            //NOTE THIS ONE SHOULD WORK FOR NEW SERVER? ALSO SINCE IT ONLY LOOKS AT HREF TAG THE <a></a> PARTS ARE NOT NEEDED
            //var regExp = /^.*(?:https:\/\/urcourses-video.uregina.ca\/index\.php\/kwidget\/wid\/_([\d]{3})\/uiconf_id\/([\d]{5,})\/entry_id\/([\d]+_[a-z0-9]+))/;
            
            var regExp = /^.*(?:http:\/\/142.3.128.141\/index\.php\/kwidget\/wid\/_([\d]{3})\/uiconf_id\/([\d]{5,})\/entry_id\/([\d]+_[a-z0-9]+))/;
         
         elements = angular.element('<div>').html(attrs.content); // Convert the content into DOM.
          //loop through each instance of <a> tag    
         angular.forEach(elements.find('a'), function(script)
         {
             var link = script.href;
             var match = link.match(regExp); 
             if (match)
             {
                var pid = match[1];
                var entryid = match[3];
                var uiconfid = attrs.uiconfid;
                 
                var s = document.createElement('iframe');
                s.id = "kalturaLib";
                s.width=attrs.width;
                s.height = attrs.height;
                //s.async = false;

                s.src = 'http://142.3.128.141/p/'+pid+'/sp/'+pid+'00/embedIframeJs/uiconf_id/'+uiconfid+'/partner_id/'+pid+'?iframeembed=true&playerId=kaltura_player&entry_id='+entryid+'&flashvars[autoPlay]=true&flashvars[share.plugin]=true';

                script.parentNode.append(s);
                //remove <a> tag from the content
                script.parentNode.removeChild(script);               
              }   
          });
         //replaces current directive content with new modified content 
         //empties and past elements in the case of directive reload     
         element.empty();
        //adds the new elements
         element.append(elements);
        });
		}                 
    }
});






