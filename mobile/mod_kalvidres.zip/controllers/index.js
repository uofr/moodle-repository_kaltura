
angular.module('mm.addons.mod_kaltura')

/**
 * Kaltura index controller.
 *
 * @module mm.addons.mod_kaltura
 * @ngdoc controller
 * @name mmaModKalturaIndexCtrl
 */
.controller('mmaModKalturaIndexCtrl', function($scope, $stateParams, $mmaModKaltura, $mmUtil, $q, $mmCourse, $mmSite, $state) {
    var module = $stateParams.module || {},
        courseId = $stateParams.courseid,
        kaltura;
    var userId = $mmSite.getUserId();
    
    $scope.pid = 106;
    $scope.id= 0;
    $scope.name= "";
    $scope.intro= "" ;
    $scope.entryid= 0;
    $scope.uiconfid =0;
    $scope.playerLoaded=false;

    /**
     * This function calls kaltura.js function to call webservice function
     */
     function getMedia(){   
        return $mmaModKaltura.getMedia(module.id).then(function(response) {
            
                var resps = response.responses;
                $scope.pid = response.pid;
                $scope.id= resps.id;
                $scope.name= resps.name;
                $scope.intro= resps.intro;
                $scope.entryid= resps.entry_id;
                $scope.uiconfid =resps.uiconf_id;
                $scope.playerLoaded=true;
            
            }).catch(function(message) {
                if (message) {
                    $mmUtil.showErrorModal(message);
                } else {
                    $mmUtil.showErrorModal('Error while getting the responses', true);
                }
                return $q.reject();
            }); 
    }
  
  getMedia();
 
       
});

